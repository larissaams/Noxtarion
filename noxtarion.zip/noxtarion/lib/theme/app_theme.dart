import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Paleta de cores extraída das variáveis CSS (:root) do index.html original.
class AppColors {
  AppColors._();

  static const bg = Color(0xFF1D201E);
  static const bgAlt = Color(0xFF2C253E);
  static const bgPanel = Color(0xFF3C2A5E);
  static const text = Color(0xFFF7F9E6);
  static const textDim = Color(0xFFC4C4C4);
  static const gold = Color(0xFFD3AF37);
  static const goldSoft = Color(0xFFF1CD55);
  static const violet = Color(0xFF7A2DC4);
  static const violetSoft = Color(0xFFCE53E0);
  static const violetDark = Color(0xFF56159A);
  static const ember = Color(0xFFE05353);
  static const line = Color(0x26C4C4C4); // rgba(196,196,196,0.15)
}

/// Fontes equivalentes às importadas via Google Fonts no HTML original:
/// --font-h1: 'UnifrakturCook'  → títulos grandes (wordmark, H1)
/// --font-h2: 'Pirata One'      → subtítulos / H2
/// --font-text: 'Skranji'       → corpo de texto
/// mono: 'JetBrains Mono'       → labels, eyebrows, botões estilo RPG-terminal
class AppFonts {
  AppFonts._();

  static TextStyle h1({double fontSize = 44, Color? color}) =>
      GoogleFonts.unifrakturCook(
        fontSize: fontSize,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.6,
        color: color ?? AppColors.text,
      );

  static TextStyle h2({double fontSize = 28, Color? color}) =>
      GoogleFonts.pirataOne(
        fontSize: fontSize,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.5,
        color: color ?? AppColors.text,
      );

  static TextStyle body({double fontSize = 15, Color? color, FontWeight? weight}) =>
      GoogleFonts.skranji(
        fontSize: fontSize,
        fontWeight: weight ?? FontWeight.w400,
        letterSpacing: 0.2,
        color: color ?? AppColors.text,
      );

  static TextStyle mono({double fontSize = 11, Color? color, double letterSpacing = 1.6}) =>
      GoogleFonts.jetBrainsMono(
        fontSize: fontSize,
        letterSpacing: letterSpacing,
        color: color ?? AppColors.goldSoft,
      );
}

/// Gradiente dourado usado em títulos e no wordmark "NOXTARION".
final goldGradient = LinearGradient(
  begin: Alignment.topCenter,
  end: Alignment.bottomCenter,
  colors: [AppColors.goldSoft, AppColors.gold],
);

ThemeData buildAppTheme() {
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: AppColors.bg,
    fontFamily: GoogleFonts.skranji().fontFamily,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.violet,
      brightness: Brightness.dark,
      background: AppColors.bg,
      primary: AppColors.violet,
      secondary: AppColors.gold,
    ),
    textTheme: TextTheme(
      bodyMedium: AppFonts.body(),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.bgAlt,
      contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.line),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.line),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: AppColors.violetSoft, width: 1.4),
      ),
      hintStyle: AppFonts.body(color: AppColors.textDim),
      labelStyle: AppFonts.mono(color: AppColors.textDim),
    ),
  );
}
