import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Equivalente ao `.adv-card` do HTML: painel com glifo numérico romano,
/// título e descrição curta.
class AdvantageCard extends StatelessWidget {
  const AdvantageCard({
    super.key,
    required this.glyph,
    required this.title,
    required this.description,
  });

  final String glyph;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.line),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.bgPanel, AppColors.bgAlt],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(glyph, style: AppFonts.h2(fontSize: 26, color: AppColors.violetSoft)),
          const SizedBox(height: 10),
          Text(title,
              style: AppFonts.body(fontSize: 16, weight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(description,
              style: AppFonts.body(fontSize: 13, color: AppColors.textDim)),
        ],
      ),
    );
  }
}
