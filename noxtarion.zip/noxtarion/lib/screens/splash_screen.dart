import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Recria a introdução "portal" do index.html: no HTML original o efeito é
/// controlado pelo scroll (canvas + smoothstep). Aqui a mesma sequência é
/// reproduzida com uma linha do tempo (AnimationController) que avança
/// sozinha, já que em um app nativo não existe uma página comprida para rolar.
/// O usuário também pode tocar na tela a qualquer momento para pular direto
/// ao botão "Entrar no portal".
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _progress;
  late final AnimationController _rotation;

  static const _introLines = [
    'Nas eras esquecidas, portais eram abertos por magia e sangue.',
    'Guardados por runas talhadas em pedra, silenciosos por séculos.',
    'Hoje, a tecnologia reacende o que o tempo apagou.',
  ];

  @override
  void initState() {
    super.initState();
    _progress = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 9),
    )..forward();
    _rotation = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 40),
    )..repeat();
  }

  @override
  void dispose() {
    _progress.dispose();
    _rotation.dispose();
    super.dispose();
  }

  double _smooth(double a, double b, double x) {
    if (a == b) return x < a ? 0 : 1;
    final t = ((x - a) / (b - a)).clamp(0.0, 1.0);
    return t * t * (3 - 2 * t);
  }

  void _skipToEnd() {
    if (_progress.value < 0.98) {
      _progress.animateTo(1, duration: const Duration(milliseconds: 400));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: GestureDetector(
        onTap: _skipToEnd,
        child: AnimatedBuilder(
          animation: Listenable.merge([_progress, _rotation]),
          builder: (context, _) {
            final p = _progress.value;
            return Stack(
              fit: StackFit.expand,
              children: [
                // Fundo em degradê radial (equivalente ao radial-gradient do #intro-stage)
                DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      radius: 1.1,
                      colors: [
                        AppColors.bgPanel,
                        AppColors.bg,
                        const Color(0xFF100D12),
                      ],
                      stops: const [0.0, 0.68, 1.0],
                    ),
                  ),
                ),
                // Portal (anéis girando, migrando de dourado "ancestral" para violeta "tecnológico")
                CustomPaint(
                  painter: _PortalPainter(
                    progress: p,
                    rotation: _rotation.value,
                  ),
                ),
                // Vinheta escurecendo as bordas
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      radius: 1.0,
                      colors: [Colors.transparent, Color(0xD9050408)],
                      stops: [0.35, 1.0],
                    ),
                  ),
                ),
                // Linhas de texto narrativo
                for (var i = 0; i < _introLines.length; i++)
                  _buildIntroLine(i, p),
                // Logo + wordmark
                _buildLogoBlock(p),
                // Dica "role para atravessar" (fica visível só no início)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 44,
                  child: Opacity(
                    opacity: 1 - _smooth(0, 0.08, p),
                    child: Column(
                      children: [
                        Text(
                          'toque para atravessar',
                          style: AppFonts.mono(color: AppColors.textDim),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          width: 1,
                          height: 34,
                          color: AppColors.goldSoft.withOpacity(0.6),
                        ),
                      ],
                    ),
                  ),
                ),
                // Botão "Entrar no portal"
                _buildEnterButton(p),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildIntroLine(int idx, double progress) {
    final start = 0.08 + idx * 0.22;
    final peak = start + 0.08;
    final end = start + 0.20;
    final a = _smooth(start, peak, progress) * (1 - _smooth(peak, end, progress));
    final dy = _lerp(14, -6, _smooth(start, end, progress));
    return Positioned.fill(
      child: Align(
        alignment: Alignment.center,
        child: Opacity(
          opacity: a.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, dy),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36),
              child: Text(
                _introLines[idx],
                textAlign: TextAlign.center,
                style: AppFonts.h2(fontSize: 22, color: AppColors.text),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogoBlock(double progress) {
    final a = _smooth(0.72, 0.88, progress);
    final scale = _lerp(0.85, 1.0, a);
    return Positioned.fill(
      child: Align(
        alignment: Alignment.center,
        child: Opacity(
          opacity: a,
          child: Transform.scale(
            scale: scale,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 90,
                  height: 90,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: AppColors.violetSoft.withOpacity(0.5), width: 2),
                    image: const DecorationImage(
                      image: AssetImage('assets/images/logo.jpeg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                ShaderMask(
                  shaderCallback: (bounds) => goldGradient.createShader(bounds),
                  child: Text(
                    'NOXTARION',
                    style: AppFonts.h1(fontSize: 46, color: Colors.white),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'um portal para todas as suas aventuras',
                  style: AppFonts.mono(color: AppColors.violetSoft),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEnterButton(double progress) {
    final a = _smooth(0.86, 0.97, progress);
    final dy = _lerp(14, 0, a);
    return Positioned(
      left: 0,
      right: 0,
      bottom: 90,
      child: IgnorePointer(
        ignoring: a < 0.5,
        child: Opacity(
          opacity: a,
          child: Transform.translate(
            offset: Offset(0, dy),
            child: Center(
              child: ElevatedButton(
                onPressed: () =>
                    Navigator.of(context).pushReplacementNamed('/landing'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.goldSoft,
                  foregroundColor: const Color(0xFF181104),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 34, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(999),
                  ),
                  elevation: 8,
                  shadowColor: AppColors.gold.withOpacity(0.6),
                ),
                child: Text(
                  'ENTRAR NO PORTAL',
                  style: AppFonts.mono(
                    color: const Color(0xFF181104),
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  double _lerp(double a, double b, double t) => a + (b - a) * t;
}

/// Desenha os anéis concêntricos do portal, migrando de um estilo "rúnico"
/// dourado para um estilo "tecnológico" violeta conforme [progress] avança —
/// mesma lógica do desenho em <canvas> do arquivo original.
class _PortalPainter extends CustomPainter {
  _PortalPainter({required this.progress, required this.rotation});

  final double progress;
  final double rotation;
  static const _ringCount = 7;

  double _smooth(double a, double b, double x) {
    if (a == b) return x < a ? 0 : 1;
    final t = ((x - a) / (b - a)).clamp(0.0, 1.0);
    return t * t * (3 - 2 * t);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxR = math.min(size.width, size.height) * 0.42;

    // Núcleo com brilho
    final corePaint = Paint()
      ..shader = RadialGradient(
        colors: [
          Color.lerp(AppColors.gold, AppColors.violetSoft, progress)!
              .withOpacity(0.35),
          Colors.transparent,
        ],
      ).createShader(Rect.fromCircle(center: center, radius: maxR * 1.3));
    canvas.drawCircle(center, maxR * 1.3, corePaint);

    for (var i = 0; i < _ringCount; i++) {
      final t = i / (_ringCount - 1);
      final travel = (progress * 1.6 + t) % 1.0;
      final r = maxR * (0.18 + travel * 0.95);
      final alphaFade =
          _smooth(0, 0.15, travel) * (1 - _smooth(0.82, 1, travel));
      if (alphaFade <= 0.01) continue;

      final ancientAlpha = alphaFade * (1 - progress) * 0.9;
      final techAlpha = alphaFade * progress * 0.9;
      final rot = rotation * 2 * math.pi * (i.isEven ? 1 : -1) + t * 6;

      if (ancientAlpha > 0.02) {
        _drawDashedCircle(
          canvas,
          center,
          r,
          rot,
          AppColors.gold.withOpacity(ancientAlpha),
          1.4,
          const [6, 10],
        );
      }
      if (techAlpha > 0.02) {
        _drawDashedCircle(
          canvas,
          center,
          r,
          -rot * 1.3,
          AppColors.violetSoft.withOpacity(techAlpha),
          1.0,
          const [2, 6],
        );
        _drawTicks(canvas, center, r, techAlpha);
      }
    }
  }

  void _drawDashedCircle(Canvas canvas, Offset center, double r, double rot,
      Color color, double strokeWidth, List<double> dash) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;
    final path = Path()
      ..addOval(Rect.fromCircle(center: Offset.zero, radius: r));
    final metrics = path.computeMetrics();
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(rot);
    for (final metric in metrics) {
      var distance = 0.0;
      var drawIt = true;
      var dashIdx = 0;
      while (distance < metric.length) {
        final len = dash[dashIdx % dash.length];
        if (drawIt) {
          canvas.drawPath(
            metric.extractPath(distance, math.min(distance + len, metric.length)),
            paint,
          );
        }
        distance += len;
        drawIt = !drawIt;
        dashIdx++;
      }
    }
    canvas.restore();
  }

  void _drawTicks(Canvas canvas, Offset center, double r, double alpha) {
    final paint = Paint()
      ..color = AppColors.violetSoft.withOpacity(alpha * 0.7)
      ..strokeWidth = 1;
    const ticks = 16;
    for (var k = 0; k < ticks; k++) {
      final a = (k / ticks) * 2 * math.pi;
      final p1 = center + Offset(math.cos(a), math.sin(a)) * r;
      final p2 = center + Offset(math.cos(a), math.sin(a)) * (r + 5);
      canvas.drawLine(p1, p2, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _PortalPainter oldDelegate) => true;
}
