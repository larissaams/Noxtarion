import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/advantage_card.dart';

/// Equivalente a #view-landing: hero, seção "Objetivo", grade de vantagens
/// e CTA final.
class LandingScreen extends StatelessWidget {
  const LandingScreen({super.key});

  static const _advantages = [
    ('I', 'Mesas sem limites',
        'Crie campanhas privadas ou abertas e convide sua party com um link.'),
    ('II', 'Qualquer sistema',
        'De D&D e Tormenta a sistemas independentes e caseiros — todos com suporte nativo.'),
    ('III', 'Fichas vivas',
        'Personagens que evoluem com a campanha, sincronizados para todos na mesa.'),
    ('IV', 'Dados justos',
        'Rolagens transparentes, com histórico visível para todos os jogadores.'),
    ('V', 'Multiplataforma',
        'Continue a aventura no computador e leve a mesa no bolso, pelo celular.'),
    ('VI', 'Sua identidade',
        'Perfil, histórico e conquistas de cada personagem que você já viveu.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildNav(context),
              _buildHero(context),
              const SizedBox(height: 24),
              _buildObjetivo(context),
              const SizedBox(height: 24),
              _buildVantagens(context),
              const SizedBox(height: 24),
              _buildFinalCta(context),
              _buildFooter(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNav(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(9),
              image: const DecorationImage(
                image: AssetImage('assets/images/logo.jpeg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (b) => goldGradient.createShader(b),
            child: Text('NOXTARION',
                style: AppFonts.h1(fontSize: 20, color: Colors.white)),
          ),
          const Spacer(),
          OutlinedButton(
            onPressed: () => Navigator.of(context).pushNamed('/login'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.goldSoft,
              side: const BorderSide(color: AppColors.gold),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(999)),
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            ),
            child: Text('ENTRAR', style: AppFonts.mono()),
          ),
        ],
      ),
    );
  }

  Widget _buildHero(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
      child: Column(
        children: [
          Text('RPG DE MESA, SEM FRONTEIRAS',
              textAlign: TextAlign.center, style: AppFonts.mono()),
          const SizedBox(height: 16),
          ShaderMask(
            shaderCallback: (b) => const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.white, AppColors.goldSoft, AppColors.gold],
            ).createShader(b),
            child: Text(
              'Crie seu mundo.\nEncontre sua party.\nViva sua aventura.',
              textAlign: TextAlign.center,
              style: AppFonts.h1(fontSize: 40, color: Colors.white),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Noxtarion é o portal onde mestres constroem campanhas, jogadores '
            'encontram mesas e qualquer sistema de RPG ganha uma casa — do '
            'papel milenar ao digital de ponta.',
            textAlign: TextAlign.center,
            style: AppFonts.body(color: AppColors.textDim),
          ),
          const SizedBox(height: 26),
          Wrap(
            spacing: 14,
            runSpacing: 12,
            alignment: WrapAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () => Navigator.of(context).pushNamed('/login'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.goldSoft,
                  foregroundColor: const Color(0xFF181104),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 26, vertical: 15),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(999)),
                ),
                child: Text('COMECE SUA AVENTURA', style: AppFonts.mono(color: const Color(0xFF181104))),
              ),
              OutlinedButton(
                onPressed: () {},
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.text,
                  side: const BorderSide(color: AppColors.line),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 26, vertical: 15),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(999)),
                ),
                child: Text('CONHECER O NOXTARION', style: AppFonts.mono(color: AppColors.text)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildObjetivo(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        children: [
          Text('OBJETIVO', style: AppFonts.mono()),
          const SizedBox(height: 10),
          Text('Um único portal para todo o seu RPG',
              textAlign: TextAlign.center, style: AppFonts.h2(fontSize: 26)),
          const SizedBox(height: 28),
          Container(
            width: 150,
            height: 150,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                  color: AppColors.gold.withOpacity(0.35), style: BorderStyle.solid),
            ),
            child: Center(
              child: Container(
                width: 110,
                height: 110,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: const DecorationImage(
                    image: AssetImage('assets/images/logo.jpeg'),
                    fit: BoxFit.cover,
                  ),
                  border: Border.all(color: AppColors.violetSoft.withOpacity(0.35)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Reunimos mestres e jogadores em um só lugar: monte suas mesas, '
            'organize fichas de personagem, role dados com seus amigos e '
            'hospede qualquer sistema — de clássicos consagrados a criações '
            'próprias. Noxtarion existe para que a única coisa em que você '
            'precise pensar seja a sua história.',
            textAlign: TextAlign.center,
            style: AppFonts.body(color: AppColors.textDim, fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildVantagens(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        children: [
          Text('VANTAGENS', style: AppFonts.mono()),
          const SizedBox(height: 10),
          Text('Feito para quem vive de imaginação',
              textAlign: TextAlign.center, style: AppFonts.h2(fontSize: 24)),
          const SizedBox(height: 6),
          Text(
            'Cada ferramenta do Noxtarion nasceu de uma necessidade real de mesa — física ou virtual.',
            textAlign: TextAlign.center,
            style: AppFonts.body(color: AppColors.textDim, fontSize: 14),
          ),
          const SizedBox(height: 26),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _advantages.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 0.82,
            ),
            itemBuilder: (context, i) {
              final (glyph, title, desc) = _advantages[i];
              return AdvantageCard(glyph: glyph, title: title, description: desc);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildFinalCta(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
      child: Column(
        children: [
          Container(height: 1, color: AppColors.line),
          const SizedBox(height: 40),
          Text(
            'Comece sua aventura junto de seus amigos\ncom qualquer sistema.',
            textAlign: TextAlign.center,
            style: AppFonts.h2(fontSize: 24),
          ),
          const SizedBox(height: 26),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pushNamed('/login'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.goldSoft,
              foregroundColor: const Color(0xFF181104),
              padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 17),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(999)),
            ),
            child: Text('ENTRAR NO NOXTARION', style: AppFonts.mono(color: const Color(0xFF181104))),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 24),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: AppColors.line)),
      ),
      alignment: Alignment.center,
      child: Text('Noxtarion — crie, convoque, jogue.',
          style: AppFonts.body(color: AppColors.textDim, fontSize: 12)),
    );
  }
}
