import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Equivalente a #view-auth.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _senhaCtrl = TextEditingController();
  bool _stayLogged = false;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _senhaCtrl.dispose();
    super.dispose();
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bem-vindo de volta ao Noxtarion.')),
      );
      Navigator.of(context).pushReplacementNamed('/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Column(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      image: const DecorationImage(
                        image: AssetImage('assets/images/logo.jpeg'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  ShaderMask(
                    shaderCallback: (b) => goldGradient.createShader(b),
                    child: Text('NOXTARION',
                        style: AppFonts.h1(fontSize: 30, color: Colors.white)),
                  ),
                  const SizedBox(height: 6),
                  Text('Crie seu mundo. Encontre sua party.',
                      style: AppFonts.body(color: AppColors.textDim, fontSize: 13)),
                  const SizedBox(height: 26),
                  Text('Entrar', style: AppFonts.h2(fontSize: 26)),
                  const SizedBox(height: 22),
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        _buildField(
                          controller: _emailCtrl,
                          label: 'E-MAIL',
                          hint: 'voce@exemplo.com',
                          keyboardType: TextInputType.emailAddress,
                          validator: (v) => (v == null || v.trim().length < 3)
                              ? 'Informe um e-mail válido'
                              : null,
                        ),
                        const SizedBox(height: 18),
                        _buildField(
                          controller: _senhaCtrl,
                          label: 'SENHA',
                          hint: '••••••••',
                          obscure: true,
                          validator: (v) => (v == null || v.isEmpty)
                              ? 'Informe sua senha'
                              : null,
                        ),
                        const SizedBox(height: 18),
                        _buildCheckboxRow(
                          value: _stayLogged,
                          onTap: () => setState(() => _stayLogged = !_stayLogged),
                          label: 'Continuar logado',
                        ),
                        const SizedBox(height: 24),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _submit,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.goldSoft,
                              foregroundColor: const Color(0xFF181104),
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(999)),
                            ),
                            child: Text('ENTRAR',
                                style: AppFonts.mono(color: const Color(0xFF181104))),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('Não tem conta? ',
                          style: AppFonts.body(color: AppColors.textDim, fontSize: 13)),
                      GestureDetector(
                        onTap: () => Navigator.of(context).pushReplacementNamed('/register'),
                        child: Text('Criar conta',
                            style: AppFonts.body(
                                color: AppColors.violetSoft,
                                fontSize: 13,
                                weight: FontWeight.w700)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  GestureDetector(
                    onTap: () => Navigator.of(context).pushReplacementNamed('/landing'),
                    child: Text('← voltar ao início',
                        style: AppFonts.body(color: AppColors.textDim, fontSize: 13)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required String hint,
    bool obscure = false,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppFonts.mono(color: AppColors.textDim, fontSize: 10)),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          obscureText: obscure,
          keyboardType: keyboardType,
          style: AppFonts.body(),
          decoration: InputDecoration(hintText: hint),
          validator: validator,
        ),
      ],
    );
  }

  Widget _buildCheckboxRow({
    required bool value,
    required VoidCallback onTap,
    required String label,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 19,
            height: 19,
            decoration: BoxDecoration(
              color: value ? AppColors.violet : AppColors.bgAlt,
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: value ? AppColors.violet : AppColors.line),
            ),
            child: value
                ? const Icon(Icons.check, size: 14, color: Colors.white)
                : null,
          ),
          const SizedBox(width: 10),
          Text(label, style: AppFonts.body(color: AppColors.textDim, fontSize: 13)),
        ],
      ),
    );
  }
}
