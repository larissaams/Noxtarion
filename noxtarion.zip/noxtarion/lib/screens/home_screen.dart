import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Equivalente a #view-home (versão mobile do dashboard, com navegação
/// inferior no lugar da sidebar do desktop).
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _navIndex = 0;

  static const _stats = [
    ('👥', 'Jogadores online', '4', 'de 5 na mesa'),
    ('🛡', 'Personagens ativos', '4', 'aventureiros'),
    ('✅', 'Tarefas do mestre', '3', 'para preparar'),
    ('📜', 'Sessões concluídas', '1', 'nesta campanha'),
  ];

  static const _characters = [
    ('LV', 'Lysandra Vell', 'Elfa · Maga · Nível 5'),
    ('BP', 'Borin Pedraparda', 'Anão · Guerreiro · Nível 5'),
    ('NS', 'Nim Salgueiro', 'Halfling · Ladino · Nível 5'),
    ('IO', 'Irmão Orun', 'Humano · Clérigo · Nível 5'),
  ];

  static const _activity = [
    ('Ecos na Biblioteca', 'Registro atualizado · 15 de ago, 19:30'),
    ('O Portão de Obsidiana', 'Sessão agendada · 29 de ago, 19:30'),
  ];

  void _toast(String msg) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  void _logout() {
    Navigator.of(context).pushReplacementNamed('/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bgAlt,
        elevation: 0,
        titleSpacing: 12,
        title: Row(
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                image: const DecorationImage(
                  image: AssetImage('assets/images/logo.jpeg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Text('NOXTARION', style: AppFonts.h1(fontSize: 18, color: AppColors.goldSoft)),
          ],
        ),
        actions: [
          GestureDetector(
            onTap: _logout,
            child: Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  image: const DecorationImage(
                    image: AssetImage('assets/images/logo.jpeg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('CAMPANHA EM ANDAMENTO', style: AppFonts.mono()),
              const SizedBox(height: 8),
              Text('Bem-vindo ao Noxtarion', style: AppFonts.h2(fontSize: 24)),
              const SizedBox(height: 6),
              Text('Tudo que sua mesa precisa para continuar a aventura.',
                  style: AppFonts.body(color: AppColors.textDim, fontSize: 13)),
              const SizedBox(height: 18),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  _quickAction('＋ Nova mesa', primary: true, onTap: () => _toast('Nova mesa — em breve.')),
                  _quickAction('📞 Abrir Chamada', onTap: () => _openCallSheet(context)),
                  _quickAction('Criar personagem', onTap: () => _toast('Criar personagem — em breve.')),
                  _quickAction('🗓 Agendar sessão', onTap: () => _toast('Agendar sessão — em breve.')),
                  _quickAction('🎲 Rolar dados', onTap: () => _toast('Rolar dados — em breve.')),
                ],
              ),
              const SizedBox(height: 24),
              _activeCampaignCard(),
              const SizedBox(height: 24),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _stats.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.5,
                ),
                itemBuilder: (context, i) {
                  final (icon, label, num, sub) = _stats[i];
                  return _statCard(icon, label, num, sub);
                },
              ),
              const SizedBox(height: 24),
              _panel(
                title: 'Personagens recentes',
                trailing: 'Ver todos',
                onTrailingTap: () => _toast('Personagens — em breve.'),
                child: Column(
                  children: _characters
                      .map((c) => _characterRow(c.$1, c.$2, c.$3))
                      .toList(),
                ),
              ),
              const SizedBox(height: 16),
              _panel(
                title: 'Atividade recente',
                child: Column(
                  children: _activity
                      .map((a) => _activityRow(a.$1, a.$2))
                      .toList(),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: AppColors.bgAlt,
        selectedIndex: _navIndex,
        onDestinationSelected: (i) {
          setState(() => _navIndex = i);
          const names = ['Dashboard', 'Mesas', 'Rolador', 'Personagens', 'Ajustes'];
          if (i != 0) _toast('${names[i]} — em breve.');
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grid_view), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.shield_outlined), label: 'Mesas'),
          NavigationDestination(icon: Icon(Icons.casino_outlined), label: 'Rolador'),
          NavigationDestination(icon: Icon(Icons.people_outline), label: 'Personagens'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Ajustes'),
        ],
      ),
    );
  }

  Widget _quickAction(String label, {bool primary = false, required VoidCallback onTap}) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: primary ? AppColors.violet : AppColors.bgAlt,
        foregroundColor: AppColors.text,
        side: primary ? BorderSide.none : const BorderSide(color: AppColors.line),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(label, style: AppFonts.body(fontSize: 13)),
    );
  }

  Widget _activeCampaignCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.bgPanel,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('CAMPANHA ATIVA', style: AppFonts.mono()),
          const SizedBox(height: 6),
          Text('As Cinzas de Valdora', style: AppFonts.h2(fontSize: 20)),
          const SizedBox(height: 4),
          Text('D&D 5e · Uma antiga ameaça desperta sob as ruínas da capital.',
              style: AppFonts.body(color: AppColors.textDim, fontSize: 13)),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.bgAlt,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('PRÓXIMA SESSÃO', style: AppFonts.mono(fontSize: 10)),
                const SizedBox(height: 4),
                Text('29 de ago, 19:30', style: AppFonts.body(fontSize: 15, weight: FontWeight.w700)),
                Text('O Portão de Obsidiana', style: AppFonts.body(color: AppColors.textDim, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statCard(String icon, String label, String num, String sub) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.bgAlt,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(icon, style: const TextStyle(fontSize: 20)),
          Text(label, style: AppFonts.body(color: AppColors.textDim, fontSize: 12)),
          RichText(
            text: TextSpan(children: [
              TextSpan(text: '$num ', style: AppFonts.h2(fontSize: 20)),
              TextSpan(text: sub, style: AppFonts.body(color: AppColors.textDim, fontSize: 11)),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _panel({
    required String title,
    String? trailing,
    VoidCallback? onTrailingTap,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.bgAlt,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: AppFonts.body(fontSize: 15, weight: FontWeight.w700)),
              if (trailing != null)
                GestureDetector(
                  onTap: onTrailingTap,
                  child: Text(trailing, style: AppFonts.body(color: AppColors.violetSoft, fontSize: 12)),
                ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _characterRow(String initials, String name, String meta) {
    return InkWell(
      onTap: () => _toast('$name — em breve.'),
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: AppColors.violet,
              child: Text(initials, style: AppFonts.body(fontSize: 12, weight: FontWeight.w700)),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: AppFonts.body(fontSize: 14, weight: FontWeight.w700)),
                Text(meta, style: AppFonts.body(color: AppColors.textDim, fontSize: 12)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _activityRow(String title, String sub) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 8,
            height: 8,
            margin: const EdgeInsets.only(top: 6, right: 12),
            decoration: const BoxDecoration(color: AppColors.goldSoft, shape: BoxShape.circle),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppFonts.body(fontSize: 14, weight: FontWeight.w700)),
                Text(sub, style: AppFonts.body(color: AppColors.textDim, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _openCallSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgPanel,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Chamada da mesa', style: AppFonts.h2(fontSize: 20, color: AppColors.goldSoft)),
              const SizedBox(height: 14),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.3,
                children: List.generate(4, (i) {
                  return Container(
                    decoration: BoxDecoration(
                      color: AppColors.bg,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.line),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      i == 0 ? 'Você' : 'Jogador ${i + 1}',
                      style: AppFonts.mono(color: AppColors.textDim),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 18),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _callCtrlButton(Icons.mic_off, 'Mudo'),
                  _callCtrlButton(Icons.videocam_off, 'Câmera'),
                  _callCtrlButton(Icons.fiber_manual_record, 'Gravar', color: AppColors.ember),
                  _callCtrlButton(Icons.call_end, 'Sair', color: AppColors.ember, onTap: () => Navigator.pop(ctx)),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _callCtrlButton(IconData icon, String label, {Color? color, VoidCallback? onTap}) {
    return Column(
      children: [
        InkWell(
          onTap: onTap ?? () {},
          borderRadius: BorderRadius.circular(30),
          child: CircleAvatar(
            radius: 24,
            backgroundColor: color ?? AppColors.bg,
            child: Icon(icon, color: Colors.white, size: 20),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: AppFonts.body(fontSize: 11, color: AppColors.textDim)),
      ],
    );
  }
}
